#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "fmqualityview.h"
#include "servoanglemanager.h"
#include "datasimulator.h"
#include"fmqualityview.h"
#include <QLabel>
#include <QPushButton>
#include <QComboBox>
#include <QLayout>
#include <QSizePolicy>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // ----- 1) Podstawowe połączenia przycisków z zakładkami -----
    connect(ui->servoAnglesBT, &QPushButton::clicked,
            this, &MainWindow::showServoAngles);
    connect(ui->animationsBT, &QPushButton::clicked,
            this, &MainWindow::showAnimations);
    connect(ui->fmServiceBT, &QPushButton::clicked,
            this, &MainWindow::showConnection);
    connect(ui->settingsBT, &QPushButton::clicked,
            this, &MainWindow::showSettings);

    // ----- 2) Inicjalizacja SideView/TopView/Combo -----
    sideView = ui->sideView;
    topView  = ui->topView;
    connect(ui->comboBoxLegSide, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::onLegSelectionChanged);

    // ----- 3) ServoAngleManager -----
    servoManager = new ServoAngleManager(this);
    for (int leg = 0; leg < 6; ++leg) {
        for (int joint = 0; joint < 3; ++joint) {
            auto name = QString("servo_%1_%2").arg(leg).arg(joint);
            if (auto *lbl = findChild<QLabel*>(name))
                servoManager->registerLabel(leg, joint, lbl);
        }
    }

    // ----- 4) DataSimulator -----
    simulator = new DataSimulator(this);
    connect(simulator, &DataSimulator::frameReady,
            this,      &MainWindow::updateServoGUI);

    // ----- 5) Podmień placeholder qualityView na wykres -----
    {
        QWidget *ph = ui->qualityView;
        QLayout *lyt = ph->parentWidget()->layout();
        lyt->removeWidget(ph);
        delete ph;
        auto *qualityView = findChild<FmQualityView*>("qualityView");


        auto *chart = new FmQualityView(this);
        chart->setObjectName("qualityView");
        chart->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        lyt->addWidget(chart);

        connect(simulator, &DataSimulator::qualitySample,
                chart,     &FmQualityView::addMeasurement);
    }

    // ----- 6) Start symulacji -----
    if (!simulator->loadData(QStringLiteral("servo_test_data.txt")))
        qWarning() << "Nie udało się załadować danych!";
    simulator->startSimulation(50);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showServoAngles() {
    ui->stackedWidget->setCurrentWidget(ui->servoAnglesWD);
}
void MainWindow::showAnimations() {
    ui->stackedWidget->setCurrentWidget(ui->animationWD);
}
void MainWindow::showConnection() {
    ui->stackedWidget->setCurrentWidget(ui->fMconnectionWD);
}
void MainWindow::showSettings() {
    ui->stackedWidget->setCurrentWidget(ui->settingsWD);
}

void MainWindow::onLegSelectionChanged(int index)
{
    sideView->setActiveLeg(index);
}

void MainWindow::updateServoGUI(const ServoFrame &frame)
{
    // 1) Aktualizacja tabelki QLabel
    for (int i = 0; i < frame.angles.size(); ++i) {
        auto name = QString("servo_%1_%2").arg(i/3).arg(i%3);
        if (auto *lbl = findChild<QLabel*>(name))
            lbl->setText(QString::number(frame.angles[i], 'f', 1) + u8"°");
    }
    // 2) TopView
    for (int leg = 0; leg < 6; ++leg) {
        float hip = frame.angles[leg*3 + 0];
        topView->setHipAngle(leg, hip - 90.0f);
    }
    // 3) SideView
    int legIdx = ui->comboBoxLegSide->currentIndex();
    float knee  = frame.angles[legIdx*3 + 1];
    float ankle = frame.angles[legIdx*3 + 2];
    sideView->setJointAngles(knee, ankle);
}
