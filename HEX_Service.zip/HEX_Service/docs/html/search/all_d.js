var searchData=
[
  ['onlegselectionchanged_0',['onLegSelectionChanged',['../classMainWindow.html#a30f79beabf8bb9fdc312d9906c1527bc',1,'MainWindow']]],
  ['ontimertick_1',['onTimerTick',['../classDataSimulator.html#a3d8ebf21315906fae7a75d962adfc6a3',1,'DataSimulator']]]
];
