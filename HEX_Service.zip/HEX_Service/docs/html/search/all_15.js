var searchData=
[
  ['widget_0',['widget',['../classUi__MainWindow.html#ab676f235c393f334b7c07935d4007925',1,'Ui_MainWindow']]]
];
