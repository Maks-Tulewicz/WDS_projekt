var searchData=
[
  ['ui_0',['ui',['../classMainWindow.html#a35466a70ed47252a0191168126a352a5',1,'MainWindow']]]
];
