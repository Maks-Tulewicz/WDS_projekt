var searchData=
[
  ['registerlabel_0',['registerLabel',['../classServoAngleManager.html#a8164bc2b8673fe1fa7cd5289b9cd4ffc',1,'ServoAngleManager']]],
  ['reset_1',['reset',['../classDataReader.html#a998814f9ba73f3773bb3007047ecbcaa',1,'DataReader']]],
  ['resetsimulation_2',['resetSimulation',['../classDataSimulator.html#a3a0a8a156f8e8ab1fbd37dd796de7386',1,'DataSimulator']]],
  ['retranslateui_3',['retranslateUi',['../classUi__MainWindow.html#a097dd160c3534a204904cb374412c618',1,'Ui_MainWindow']]]
];
