var searchData=
[
  ['loaddata_0',['loadData',['../classDataSimulator.html#aa1827f25f036fb988cf594d60e384d16',1,'DataSimulator']]],
  ['loadfromfile_1',['loadFromFile',['../classDataReader.html#ae90700be1801c10fae55ac4de0616dcc',1,'DataReader']]]
];
