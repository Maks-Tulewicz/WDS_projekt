var searchData=
[
  ['reader_0',['reader',['../classDataSimulator.html#a12dc3fbb1b60501104ff97f88d157e58',1,'DataSimulator']]],
  ['right_5fwidget_1',['right_widget',['../classUi__MainWindow.html#a8dcd8779d3b2737faa24fc990ae82370',1,'Ui_MainWindow']]]
];
