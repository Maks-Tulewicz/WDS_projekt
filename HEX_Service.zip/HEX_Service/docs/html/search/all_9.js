var searchData=
[
  ['kneeangle_0',['kneeAngle',['../classSideView.html#ae9538f9a5e658612ff71ef487a11199b',1,'SideView']]],
  ['kolano_5fname_1',['kolano_name',['../classUi__MainWindow.html#ada9a0136deba835ef68ec26ef26ea421',1,'Ui_MainWindow']]],
  ['kostka_5fname_2',['kostka_name',['../classUi__MainWindow.html#a925a6a56762f034bb55630c53c9443a7',1,'Ui_MainWindow']]]
];
