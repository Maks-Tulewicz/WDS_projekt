var searchData=
[
  ['grid_5ffiller_0',['grid_filler',['../classUi__MainWindow.html#ab4214b2f7aee7913078132c1d181b1a4',1,'Ui_MainWindow']]],
  ['gridlayout_1',['gridLayout',['../classUi__MainWindow.html#a525ed3c5fe0784ac502ee222fba4e205',1,'Ui_MainWindow']]]
];
