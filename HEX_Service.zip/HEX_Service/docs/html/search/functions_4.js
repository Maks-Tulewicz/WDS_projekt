var searchData=
[
  ['next_0',['next',['../classDataReader.html#a404003dfbe7d988e49bccdea9784c90a',1,'DataReader']]]
];
