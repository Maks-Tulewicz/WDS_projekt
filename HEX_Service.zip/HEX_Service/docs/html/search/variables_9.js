var searchData=
[
  ['left_5fwidget_0',['left_widget',['../classUi__MainWindow.html#a7b5a03030191f515b2cff464fe66e10a',1,'Ui_MainWindow']]],
  ['leftpanel_1',['leftPanel',['../classUi__MainWindow.html#aecca7c80ca4c24516b08279d4e583695',1,'Ui_MainWindow']]],
  ['line_2',['line',['../classUi__MainWindow.html#a16e802a7ebd4beb9d8aba858565e51b3',1,'Ui_MainWindow']]]
];
