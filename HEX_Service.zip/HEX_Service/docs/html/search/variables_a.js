var searchData=
[
  ['noga_5f1_5fname_0',['noga_1_name',['../classUi__MainWindow.html#a9b1d3edec3d74c4ba060dc1879b56df2',1,'Ui_MainWindow']]],
  ['noga_5f2_5fname_1',['noga_2_name',['../classUi__MainWindow.html#add2ef990954e7c3f170870d8bb39291c',1,'Ui_MainWindow']]],
  ['noga_5f3_5fname_2',['noga_3_name',['../classUi__MainWindow.html#a2a82b5e19f66463067baa3a2d25b11c3',1,'Ui_MainWindow']]],
  ['noga_5f4_5fname_3',['noga_4_name',['../classUi__MainWindow.html#a141e6c32419046ac9a34c1f28cd2d0ae',1,'Ui_MainWindow']]],
  ['noga_5f5_5fname_4',['noga_5_name',['../classUi__MainWindow.html#a687a2b6dc7989a630b970e4f497358af',1,'Ui_MainWindow']]],
  ['noga_5f6_5fname_5',['noga_6_name',['../classUi__MainWindow.html#a0b03002f3c039e3b68dac78ae5bcfd8d',1,'Ui_MainWindow']]]
];
