var searchData=
[
  ['biodro_5fname_0',['biodro_name',['../classUi__MainWindow.html#abfcdda271b56bb1d8cf7370f06825223',1,'Ui_MainWindow']]]
];
