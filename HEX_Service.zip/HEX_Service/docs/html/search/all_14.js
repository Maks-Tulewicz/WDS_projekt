var searchData=
[
  ['verticallayout_0',['verticalLayout',['../classUi__MainWindow.html#aecd96a04789fcfec3f98d80390ad8184',1,'Ui_MainWindow']]],
  ['verticallayout_5f2_1',['verticalLayout_2',['../classUi__MainWindow.html#a0c01bad60d9f422a1258e710635a2f65',1,'Ui_MainWindow']]],
  ['verticallayout_5f3_2',['verticalLayout_3',['../classUi__MainWindow.html#a38b8a4b887f3b58e2a49e7905ae6f1f0',1,'Ui_MainWindow']]]
];
